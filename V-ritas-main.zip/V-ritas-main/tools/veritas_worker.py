"""Véritas tools catalog bridge.

This Python file is intentionally lightweight. The active runtime for Véritas v2.4
is the JavaScript/Cloudflare stack:

- Master tool registry: ``lib/toolRegistry.server.js``
- Frontend mirror: ``lib/toolRegistry.js``
- Service registry / key rotation: ``lib/keyRotator.js``
- Tool handlers: ``lib/tools/*.js``
- HTTP adapters: ``lib/services/*.js`` and ``lib/services/oauth/*.js``

Previous experimental Python tool runners used provider-specific names that no
longer match the product. To avoid drift, this module now exposes only the
current canonical names for external scripts that want to inspect the catalog.
It does not execute tools; execution must go through ``/api/tool/invoke``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True)
class ToolInfo:
    """Minimal metadata for a canonical Véritas tool."""

    name: str
    category: str
    requires_oauth: str | None = None


CURRENT_TOOLS: Final[tuple[ToolInfo, ...]] = (
    # Internal/project
    ToolInfo("search_repository", "project"),
    ToolInfo("read_project_file", "project"),
    ToolInfo("write_project_file", "project"),
    ToolInfo("create_skill", "project"),
    ToolInfo("preview_html", "project"),
    ToolInfo("load_template", "project"),
    ToolInfo("fetch_via_proxy", "project"),
    # Search/scraping/browser
    ToolInfo("web_search", "research"),
    ToolInfo("scrape_url", "research"),
    ToolInfo("firecrawl_scrape", "research"),
    ToolInfo("firecrawl_crawl", "research"),
    ToolInfo("gdelt_search", "research"),
    ToolInfo("jina_reader_search", "research"),
    ToolInfo("jina_github_search", "research"),
    ToolInfo("rover_scrape", "research"),
    ToolInfo("spider_cloud_search", "research"),
    ToolInfo("browserless_execute", "browser"),
    ToolInfo("browser_use_browse", "browser"),
    ToolInfo("browser_use_cloud", "browser"),
    ToolInfo("steel_session", "browser"),
    ToolInfo("steel_auth_session", "browser"),
    # OSINT/infrastructure
    ToolInfo("dns_lookup", "osint"),
    ToolInfo("shodan_search", "osint"),
    ToolInfo("zoomeye_search", "osint"),
    ToolInfo("intelx_search", "osint"),
    ToolInfo("apify_google_places", "osint"),
    ToolInfo("apify_social", "osint"),
    ToolInfo("gfw_search", "osint"),
    ToolInfo("ner_extract", "analysis"),
    # Documents/media
    ToolInfo("analyze_media", "media"),
    ToolInfo("llamaparse_parse", "document"),
    ToolInfo("assemblyai_transcribe", "media"),
    # OAuth
    ToolInfo("github_list_repos", "oauth", "github"),
    ToolInfo("github_read_file", "oauth", "github"),
    ToolInfo("github_write_file", "oauth", "github"),
    ToolInfo("github_write_files", "oauth", "github"),
    ToolInfo("github_create_branch", "oauth", "github"),
    ToolInfo("github_create_pr", "oauth", "github"),
    ToolInfo("dropbox_list_folder", "oauth", "dropbox"),
    ToolInfo("dropbox_read_file", "oauth", "dropbox"),
    ToolInfo("dropbox_write_file", "oauth", "dropbox"),
    ToolInfo("dropbox_search", "oauth", "dropbox"),
    ToolInfo("dropbox_upload_large", "oauth", "dropbox"),
)

CURRENT_SERVICES: Final[tuple[str, ...]] = (
    "openrouter",
    "jina",
    "tavily",
    "serper",
    "scrapingbee",
    "firecrawl",
    "browser_use",
    "steel",
    "rover",
    "spider_cloud",
    "browserless",
    "apify",
    "llamaparse",
    "assemblyai",
    "shodan",
    "zoomeye",
    "intelx",
    "jina_reader",
    "gfw",
    "jina_github",
    "steel_auth",
)

FALLBACK_CHAINS: Final[dict[str, tuple[str, ...]]] = {
    "news_events": ("gdelt_search", "web_search", "scrape_url", "firecrawl_scrape"),
    "web_page": ("scrape_url", "firecrawl_scrape", "browserless_execute", "steel_session"),
    "browser_task": ("browserless_execute", "steel_session", "browser_use_browse", "browser_use_cloud"),
    "infrastructure": ("dns_lookup", "shodan_search", "zoomeye_search", "intelx_search"),
    "documents": ("llamaparse_parse", "analyze_media", "read_project_file"),
    "project_code": ("search_repository", "read_project_file", "write_project_file", "preview_html"),
}


def list_tools() -> tuple[str, ...]:
    """Return canonical tool names."""

    return tuple(tool.name for tool in CURRENT_TOOLS)


def list_services() -> tuple[str, ...]:
    """Return canonical service names used by the JS key rotator."""

    return CURRENT_SERVICES


def get_fallback_chain(name: str) -> tuple[str, ...]:
    """Return a named advisory fallback chain."""

    return FALLBACK_CHAINS.get(name, ())


__all__ = [
    "ToolInfo",
    "CURRENT_TOOLS",
    "CURRENT_SERVICES",
    "FALLBACK_CHAINS",
    "list_tools",
    "list_services",
    "get_fallback_chain",
]
